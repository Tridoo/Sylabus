package tridoo.sylabus;

import android.animation.AnimatorInflater;
import android.animation.AnimatorSet;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.app.Activity;
import android.content.ClipData;
import android.graphics.Typeface;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.DragShadowBuilder;
import android.view.View.OnDragListener;
import android.view.View.OnTouchListener;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.RotateAnimation;
import android.view.animation.TranslateAnimation;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.Space;
import android.widget.Spinner;
import android.widget.TextView;

import android.media.AudioManager;
import android.media.SoundPool;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Random;
import android.speech.tts.TextToSpeech;
import android.widget.ToggleButton;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


public class MainActivity extends Activity {
    Map slownikMapa = new Hashtable();
    Map slownikMapaPRV = new Hashtable();

    List<Integer> tabPoprawnosci = new ArrayList<Integer>();
    LinearLayout layZrodlo;
    LinearLayout layCel;
    RelativeLayout layAdd;
    LinearLayout layPkt;
    LinearLayout layPkt2;
    ImageButton btnPodp;
    ImageView usmiech;
    ImageView smutek;
    TextView komunikat;
    TextView podpowiedz;
    TextView odpowiedz;
    EditText editS1;
    EditText editS2;
    EditText editS3;
    EditText editS4;
    EditText editS5;
    Spinner spiner;

    SoundPool sounds;
    ArrayList tada = new ArrayList();
    ArrayList err = new ArrayList();
    String kategoria;
    String odpTXT="";
    Boolean czyPoziom3=true;
    Boolean czyPoziom4=true;
    Boolean czyPoziom5=true;
    String [] listaKategorii;
    Context context;

    final int KAT_ZWIERZ=1;
    final int KAT_ROSLINA=2;
    final int KAT_OSOBA=3;
    final int KAT_RZECZ=4;

    boolean czyDemo=false;

    ImageView chmura1;
    ImageView chmura2;
    ImageView chmura3;
    ImageView chmura4;

    Animation animChmura1;
    Animation animChmura2;
    Animation animChmura3;
    Animation animChmura4;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout._activity_main);
        layZrodlo = (LinearLayout) findViewById(R.id.layZrodlo);
        layCel = (LinearLayout) findViewById(R.id.layCel);
        layPkt = (LinearLayout) findViewById(R.id.layPkt);
        layPkt2 = (LinearLayout) findViewById(R.id.layPkt2);
        usmiech= (ImageView) findViewById(R.id.usmiech);
        smutek= (ImageView) findViewById(R.id.smutek);
        usmiech.setVisibility(View.INVISIBLE);
        smutek.setVisibility(View.INVISIBLE);
        komunikat=(TextView)findViewById(R.id.komunikat);
        komunikat.setVisibility(View.INVISIBLE);
        podpowiedz=(TextView)findViewById(R.id.podpowiedz);
        podpowiedz.setVisibility(View.INVISIBLE);
        odpowiedz=(TextView)findViewById(R.id.odpowiedz);
        odpowiedz.setVisibility(View.INVISIBLE);

        editS1=(EditText)findViewById(R.id.sylaba1);
        editS2=(EditText)findViewById(R.id.sylaba2);
        editS3=(EditText)findViewById(R.id.sylaba3);
        editS4=(EditText)findViewById(R.id.sylaba4);
        editS5=(EditText)findViewById(R.id.sylaba5);
        spiner=(Spinner)findViewById(R.id.spKategoria);
        context=this;


        ImageButton btnRestart = (ImageButton) findViewById(R.id.btnRestart);
        btnRestart.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nowaGra();
            }
        });

        btnPodp = (ImageButton) findViewById(R.id.btnPodpowiedz);
        btnPodp.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyswietlPodpowiedz();
            }
        });

        ToggleButton btnPoziom3= (ToggleButton) findViewById(R.id.btnPoziom3);
        btnPoziom3.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (((ToggleButton)v).isChecked()) czyPoziom3=true;
                else czyPoziom3=false;
            }
        });

        ToggleButton btnPoziom4= (ToggleButton) findViewById(R.id.btnPoziom4);
        btnPoziom4.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (((ToggleButton)v).isChecked()) czyPoziom4=true;
                else czyPoziom4=false;
            }
        });

        ToggleButton btnPoziom5= (ToggleButton) findViewById(R.id.btnPoziom5);
        btnPoziom5.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                if (((ToggleButton)v).isChecked()) czyPoziom5=true;
                else czyPoziom5=false;
            }
        });

        ImageButton btnAdd = (ImageButton) findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                layAdd.setVisibility(View.VISIBLE);
            }
        });

        layAdd = (RelativeLayout) findViewById(R.id.layAdd);
        layAdd.setVisibility(View.INVISIBLE);

        ImageButton btnCancel = (ImageButton) findViewById(R.id.btnCacnel);
        btnCancel.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                wyczyscFormatke();
                layAdd.setVisibility(View.INVISIBLE);
            }
        });

        ImageButton btnOK = (ImageButton) findViewById(R.id.btnOk);
        btnOK.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                String pNoweslowo=noweSlowo();
                int pNrKategorii=(int)spiner.getSelectedItemId();
                if (pNoweslowo.length()>0 && pNrKategorii>0){
                    slownikMapaPRV.put(pNoweslowo,pNrKategorii);
                    slownikMapa.put(pNoweslowo,pNrKategorii);
                    wyczyscFormatke();
                    layAdd.setVisibility(View.INVISIBLE);
                    zapiszSlownikPRV();
                }else{
                    new AlertDialog.Builder(context)
                            .setTitle("BŁĄD")
                            .setMessage("Błędne dane")
                            .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int which) {                   }
                            })
                            .setIcon(android.R.drawable.ic_dialog_alert)
                            .show();
                }
            }
        });

        listaKategorii=getResources().getStringArray(R.array.lista_kategorii);
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,listaKategorii);
        spiner.setAdapter(adapter);

        if(czyDemo) {
            wypelnijSlownikDemo();
            btnAdd.setVisibility(View.INVISIBLE);
            AdView mAdView = (AdView) findViewById(R.id.adView);
            AdRequest adRequest = new AdRequest.Builder().build();
            mAdView.loadAd(adRequest);
        }
        else {
            wypelnijSlownikDemo();
            dodajSlowaPremium();
            dodajSlowaPRV();
        }

        wypelnijLay(losujSlowo(slownikMapa));
        wczytajDzwieki();

        //animacjaChmur();
    }

    private void  animacjaChmur(){
        chmura1 = (ImageView) findViewById(R.id.chmura1);
        chmura2 = (ImageView) findViewById(R.id.chmura2);
        chmura3 = (ImageView) findViewById(R.id.chmura3);
        chmura4 = (ImageView) findViewById(R.id.chmura4);

        animChmura1 = AnimationUtils.loadAnimation(this, R.anim.anim_chmura1);
        animChmura2 = AnimationUtils.loadAnimation(this, R.anim.anim_chmura2);
        animChmura3 = AnimationUtils.loadAnimation(this, R.anim.anim_chmura3);
        animChmura4 = AnimationUtils.loadAnimation(this, R.anim.anim_chmura4);

        chmura1.startAnimation(animChmura1);
        chmura2.startAnimation(animChmura2);
        chmura3.startAnimation(animChmura3);
        chmura4.startAnimation(animChmura4);

        animChmura1.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {      }

            @Override
            public void onAnimationEnd(Animation a) {
                a.setAnimationListener(null);
                a = AnimationUtils.loadAnimation(context, R.anim.anim_chmura1);
                a.setAnimationListener(this);

                chmura1.clearAnimation();
                chmura1.setAnimation(a);
                chmura1.startAnimation(a);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {   }
        });

        animChmura2.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {      }

            @Override
            public void onAnimationEnd(Animation a) {
                a.setAnimationListener(null);
                a = AnimationUtils.loadAnimation(context, R.anim.anim_chmura2);
                a.setAnimationListener(this);

                chmura2.clearAnimation();
                chmura2.setAnimation(a);
                chmura2.startAnimation(a);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {   }
        });

        animChmura3.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {      }

            @Override
            public void onAnimationEnd(Animation a) {
                a.setAnimationListener(null);
                a = AnimationUtils.loadAnimation(context, R.anim.anim_chmura3);
                a.setAnimationListener(this);

                chmura3.clearAnimation();
                chmura3.setAnimation(a);
                chmura3.startAnimation(a);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {   }
        });

        animChmura4.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {      }

            @Override
            public void onAnimationEnd(Animation a) {
                a.setAnimationListener(null);
                a = AnimationUtils.loadAnimation(context, R.anim.anim_chmura4);
                a.setAnimationListener(this);

                chmura4.clearAnimation();
                chmura4.setAnimation(a);
                chmura4.startAnimation(a);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {   }
        });

    }

    private String noweSlowo(){
        int pIleSylab=0;
        String pWyraz="";

        String pSylaba1=editS1.getText().toString();
        String pSylaba2=editS2.getText().toString();
        String pSylaba3=editS3.getText().toString();
        String pSylaba4=editS4.getText().toString();
        String pSylaba5=editS5.getText().toString();

        if (pSylaba1.length()>0) pIleSylab++;
        if (pSylaba2.length()>0) pIleSylab++;
        if (pSylaba3.length()>0) pIleSylab++;
        if (pSylaba4.length()>0) pIleSylab++;
        if (pSylaba5.length()>0) pIleSylab++;

        if (pIleSylab<3) return pWyraz;
        else{
            pWyraz=pSylaba1+','+pSylaba2+','+pSylaba3+','+pSylaba4+','+pSylaba5;
            pWyraz=pWyraz.replace(",,",",");
            if (pWyraz.startsWith(",")) pWyraz=pWyraz.substring(1);
            if (pWyraz.endsWith(",")) pWyraz=pWyraz.substring(0,pWyraz.length()-1);
            return pWyraz.trim().toUpperCase();
        }
    }

    private void wyczyscFormatke(){
        editS1.setText("");
        editS2.setText("");
        editS3.setText("");
        editS4.setText("");
        editS5.setText("");
        spiner.setSelection(0);
    }

    private void wczytajDzwieki(){
        sounds =new SoundPool(10,AudioManager.STREAM_MUSIC,0);
        tada.add(sounds.load(this, R.raw.tada0,1));
        tada.add(sounds.load(this, R.raw.tada1,1));
        tada.add(sounds.load(this, R.raw.tada2,1));
        tada.add(sounds.load(this, R.raw.tada3,1));
        tada.add(sounds.load(this, R.raw.tada4,1));
        tada.add(sounds.load(this, R.raw.tada5,1));
        tada.add(sounds.load(this, R.raw.tada6,1));
        tada.add(sounds.load(this, R.raw.tada7,1));
        tada.add(sounds.load(this, R.raw.tada8,1));

        err.add(sounds.load(this, R.raw.err0,1));
        err.add(sounds.load(this, R.raw.err1,1));
        err.add(sounds.load(this, R.raw.err2,1));
        err.add(sounds.load(this, R.raw.err3,1));
        err.add(sounds.load(this, R.raw.err4,1));
        err.add(sounds.load(this, R.raw.err5,1));
        err.add(sounds.load(this, R.raw.err6,1));
        err.add(sounds.load(this, R.raw.err7,1));
        err.add(sounds.load(this, R.raw.err8,1));
    }

    private void wypelnijLay(String[] aSlowo){
        int ilosc=aSlowo.length;
        TextView[] tvZrodlo=new TextView[ilosc];
        TextView[] tvCel=new TextView[ilosc];

        for (int i=0;i<ilosc;i++){
            LinearLayout.LayoutParams lparams = new LinearLayout.LayoutParams(
                    120,120,1.0f);
            lparams.setMargins(30,30,30,30);

            tvZrodlo[i] = new TextView(this);
            tvZrodlo[i].setLayoutParams(lparams);
            tvZrodlo[i].setId(1000+i);
            tvZrodlo[i].setGravity(Gravity.CENTER);
            tvZrodlo[i].setBackgroundResource(R.drawable.rounded_corner);
            tvZrodlo[i].setLayoutParams(lparams);
            tvZrodlo[i].setTextSize(25);
            tvZrodlo[i].setText(aSlowo[i]);
            tvZrodlo[i].setOnTouchListener(new ChoiceTouchListener());
        }
        //losowanie kolejnosci
        int[] tabPozycji = new int[ilosc];
        for (int i=0;i<ilosc;i++) {
            tabPoprawnosci.add(0);
            tabPozycji[i]=i;
        }
        tabPozycji=RandomizeArray(tabPozycji);

        for (int i=0;i<ilosc;i++) {
            layZrodlo.addView(tvZrodlo[tabPozycji[i]]);
        }

        for (int i=0;i<ilosc;i++){
            LinearLayout.LayoutParams lparams = new LinearLayout.LayoutParams(
                    120,120,1.0f);
            lparams.setMargins(30,30,30,30);

            tvCel[i] = new TextView(this);
            tvCel[i].setLayoutParams(lparams);
            tvCel[i].setId(2000+i);
            tvCel[i].setGravity(Gravity.CENTER);
            tvCel[i].setBackgroundResource(R.drawable.rounded_corner_dark);
            tvCel[i].setLayoutParams(lparams);
            tvCel[i].setTextSize(25);
            layCel.addView(tvCel[i]);
            tvCel[i].setOnDragListener(new ChoiceDragListener());
            tvCel[i].setOnTouchListener(new ChoiceTouchListener2());
        }
    }

    private String[] losujSlowo(Map aSlownikMapa) {
        boolean pCzySlowoDozwolone=false;
        String[] pSlowo;
        String   randomKey;
        int   aKategoria;

        do {
            do {
                Random random = new Random();
                List<String> keys = new ArrayList<String>(aSlownikMapa.keySet());
                randomKey = keys.get(random.nextInt(keys.size()));
                aKategoria = (int) aSlownikMapa.get(randomKey);
            }while(odpTXT.equals(randomKey.replace(",","")));

            pSlowo = randomKey.toUpperCase().split(",");
            switch (pSlowo.length) {
                case 3:
                    if (czyPoziom3) pCzySlowoDozwolone = true;
                    else pCzySlowoDozwolone = false;
                    break;
                case 4:
                    if (czyPoziom4) pCzySlowoDozwolone = true;
                    else pCzySlowoDozwolone = false;
                    break;
                case 5:
                    if (czyPoziom5) pCzySlowoDozwolone = true;
                    else pCzySlowoDozwolone = false;
                    break;
            }
        }while (!pCzySlowoDozwolone);

        odpTXT=randomKey.replace(",","");

        switch (aKategoria){
            case KAT_ROSLINA:
                kategoria="ROŚLINA";
                break;
            case KAT_ZWIERZ:
                kategoria="ZWIERZĘ";
                break;
            case KAT_RZECZ:
                kategoria="RZECZ";
                break;
            case KAT_OSOBA:
                kategoria="OSOBA";
                break;
        }
        return  pSlowo;
    }

    private void nowaGra(){
        if (czyPoziom3||czyPoziom4||czyPoziom5) {
            layZrodlo.removeAllViews();
            layCel.removeAllViews();
            usmiech.setVisibility(View.INVISIBLE);
            smutek.setVisibility(View.INVISIBLE);
            komunikat.setVisibility(View.INVISIBLE);
            podpowiedz.setVisibility(View.INVISIBLE);
            odpowiedz.setVisibility(View.INVISIBLE);
            tabPoprawnosci.removeAll(tabPoprawnosci);
            rozbicieSlowa();
            wypelnijLay(losujSlowo(slownikMapa));
            btnPodp.setEnabled(true);
        }
    }

    private void zapiszSlownikPRV(){
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        SharedPreferences.Editor editor = prefs.edit();
        JSONObject pSlownikJS= new JSONObject(slownikMapaPRV);
        editor.putString("json", pSlownikJS.toString());
        editor.apply();
        //editor.clear().commit();//czyszczenie
    }

    private void dodajSlowaPRV(){
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        Map pMapa = new Hashtable();
        String jString = prefs.getString("json", null);

        if (jString == null || jString.isEmpty()) {
            return;
        }
        try {
            JSONObject pSlownikJS = new JSONObject(jString);
            Iterator keys = pSlownikJS.keys();
            while (keys.hasNext()) {
                String key = (String) keys.next();
                pMapa.put(key, pSlownikJS.get(key));
            }
            slownikMapaPRV.putAll(pMapa);
            slownikMapa.putAll(pMapa);
        } catch (JSONException e) {
            e.printStackTrace();
        }
    }

    private void wypelnijSlownikDemo() {
        slownikMapa.put("pa,pu,ga", KAT_ZWIERZ);
        slownikMapa.put("ja,gu,ar", KAT_ZWIERZ);
        slownikMapa.put("ko,zi,ca", KAT_ZWIERZ);
        slownikMapa.put("kro,ko,dyl", KAT_ZWIERZ);
        slownikMapa.put("pan,te,ra", KAT_ZWIERZ);
        slownikMapa.put("no,so,ro,żec",KAT_ZWIERZ);

        slownikMapa.put("to,po,la",KAT_ROSLINA);
        slownikMapa.put("cyt,ry,na",KAT_ROSLINA);
        slownikMapa.put("a,wo,ka,do",KAT_ROSLINA);
        slownikMapa.put("po,rzecz,ka",KAT_ROSLINA);
        slownikMapa.put("ja,go,da",KAT_ROSLINA);

        slownikMapa.put("in,for,ma,ty,ka",KAT_RZECZ);
        slownikMapa.put("ko,ro,na",KAT_RZECZ);
        slownikMapa.put("za,baw,ka",KAT_RZECZ);
        slownikMapa.put("he,li,kop,ter",KAT_RZECZ);

        slownikMapa.put("ko,le,ga",KAT_OSOBA);
        slownikMapa.put("ad,wo,kat",KAT_OSOBA);
        slownikMapa.put("ak,ro,ba,ta",KAT_OSOBA);
        slownikMapa.put("de,tek,tyw",KAT_OSOBA);
        slownikMapa.put("e,ko,no,mi,sta",KAT_OSOBA);
    }

    private void dodajSlowaPremium(){
        slownikMapa.put("ce,bu,la",KAT_ROSLINA);
        slownikMapa.put("cze,reś,nia",KAT_ROSLINA);
        slownikMapa.put("je,mio,ła",KAT_ROSLINA);
        slownikMapa.put("je,ży,na",KAT_ROSLINA);
        slownikMapa.put("ko,ni,czy,na",KAT_ROSLINA);
        slownikMapa.put("ma,li,na",KAT_ROSLINA);
        slownikMapa.put("po,ziom,ka",KAT_ROSLINA);
        slownikMapa.put("ru,mia,nek",KAT_ROSLINA);

        slownikMapa.put("me,du,za",KAT_ZWIERZ);
        slownikMapa.put("a,na,kon,da",KAT_ZWIERZ);
        slownikMapa.put("an,ty,lo,pa",KAT_ZWIERZ);
        slownikMapa.put("ga,ze,la",KAT_ZWIERZ);
        slownikMapa.put("ka,me,le,on",KAT_ZWIERZ);
        slownikMapa.put("le,ni,wiec",KAT_ZWIERZ);
        slownikMapa.put("ła,si,ca",KAT_ZWIERZ);
        slownikMapa.put("mrów,ko,jad",KAT_ZWIERZ);
        slownikMapa.put("o,ce,lot",KAT_ZWIERZ);
        slownikMapa.put("pan,cer,nik",KAT_ZWIERZ);
        slownikMapa.put("pe,li,kan",KAT_ZWIERZ);
        slownikMapa.put("pi,ra,nia",KAT_ZWIERZ);
        slownikMapa.put("re,ni,fer",KAT_ZWIERZ);
        slownikMapa.put("ro,pu,cha",KAT_ZWIERZ);
        slownikMapa.put("su,ry,kat,ka",KAT_ZWIERZ);
        slownikMapa.put("szyn,szy,la",KAT_ZWIERZ);
        slownikMapa.put("ta,ran,tu,la",KAT_ZWIERZ);
        slownikMapa.put("wie,wiór,ka",KAT_ZWIERZ);
        slownikMapa.put("ży,ra,fa",KAT_ZWIERZ);

        slownikMapa.put("a,ba,żur",KAT_RZECZ);
        slownikMapa.put("dra,bi,na",KAT_RZECZ);
        slownikMapa.put("dy,na,mit",KAT_RZECZ);
        slownikMapa.put("dłu,go,pis",KAT_RZECZ);
        slownikMapa.put("fla,mas,ter",KAT_RZECZ);
        slownikMapa.put("gaś,ni,ca",KAT_RZECZ);
        slownikMapa.put("kaj,zer,ka",KAT_RZECZ);
        slownikMapa.put("ka,lo,ry,fer",KAT_RZECZ);
        slownikMapa.put("ka,na,pa",KAT_RZECZ);
        slownikMapa.put("ka,ta,log",KAT_RZECZ);
        slownikMapa.put("kier,ow,ni,ca",KAT_RZECZ);
        slownikMapa.put("kla,wia,tu,ra",KAT_RZECZ);
        slownikMapa.put("na,leś,nik",KAT_RZECZ);
        slownikMapa.put("rę,ka,wicz,ka",KAT_RZECZ);
        slownikMapa.put("su,kien,ka",KAT_RZECZ);
        slownikMapa.put("ła,do,war,ka",KAT_RZECZ);
        slownikMapa.put("lo,ko,mo,ty,wa",KAT_RZECZ);
        slownikMapa.put("ma,ku,la,tu,ra",KAT_RZECZ);
        slownikMapa.put("mag,ne,to,fon",KAT_RZECZ);
        slownikMapa.put("ag,lo,me,rac,ja",KAT_RZECZ);
        slownikMapa.put("cza,so,pis,mo",KAT_RZECZ);
        slownikMapa.put("cze,ko,la,da",KAT_RZECZ);
        slownikMapa.put("kli,ma,ty,za,cja",KAT_RZECZ);

        slownikMapa.put("a,sys,tent",KAT_OSOBA);
        slownikMapa.put("cu,kier,nik",KAT_OSOBA);
        slownikMapa.put("e,lek,tryk",KAT_OSOBA);
        slownikMapa.put("fo,to,graf",KAT_OSOBA);
        slownikMapa.put("ko,mi,niarz",KAT_OSOBA);
        slownikMapa.put("kon,duk,tor",KAT_OSOBA);
        slownikMapa.put("la,kier,nik",KAT_OSOBA);
        slownikMapa.put("lis,to,nosz",KAT_OSOBA);
        slownikMapa.put("me,cha,nik",KAT_OSOBA);
        slownikMapa.put("og,rod,nik",KAT_OSOBA);
        slownikMapa.put("o,pe,ra,tor",KAT_OSOBA);
        slownikMapa.put("o,pie,kun,ka",KAT_OSOBA);
        slownikMapa.put("ra,tow,nik",KAT_OSOBA);
        slownikMapa.put("ta,pi,cer",KAT_OSOBA);
        slownikMapa.put("tak,sów,karz",KAT_OSOBA);
    }

    private final class ChoiceTouchListener implements OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                //setup drag
                ClipData data = ClipData.newPlainText("", "");
                DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
                //start dragging the item touched
                view.startDrag(data, shadowBuilder, view, 0);
                return true;
            }
            else {
                return false;
            }
        }
    }

    private final class ChoiceTouchListener2 implements OnTouchListener {
        public boolean onTouch(View view, MotionEvent motionEvent) {
            if (motionEvent.getAction() == MotionEvent.ACTION_DOWN) {
                //setup drag
                //ClipData data = ClipData.newPlainText("", "");
                //DragShadowBuilder shadowBuilder = new View.DragShadowBuilder(view);
                //start dragging the item touched
                //view.startDrag(data, shadowBuilder, view, 0);

                if (view.getTag() != null){
                    TextView tv=(TextView) findViewById((int)view.getTag());
                    tv.setVisibility(View.VISIBLE);

                    ((TextView)view).setText("");
                    view.setTag(null);
                    view.setBackgroundResource(R.drawable.rounded_corner_dark);
                    tabPoprawnosci.set(view.getId()-2000,0);
                }
                return true;
            }
            else {
                return false;
            }
        }
    }

    private class ChoiceDragListener implements OnDragListener {
        @Override
        public boolean onDrag(View v, DragEvent event) {
            //handle drag events
            switch (event.getAction()) {
                case DragEvent.ACTION_DRAG_STARTED:
                    //no action necessary
                    break;
                case DragEvent.ACTION_DRAG_ENTERED:
                    //no action necessary
                    break;
                case DragEvent.ACTION_DRAG_EXITED:
                    //no action necessary
                    break;
                case DragEvent.ACTION_DROP:
                    //handle the dragged view being dropped over a drop view
//handle the dragged view being dropped over a target view
                    View view = (View) event.getLocalState();
                    //stop displaying the view where it was before it was dragged
                    view.setVisibility(View.INVISIBLE);
                    //view dragged item is being dropped on
                    TextView dropTarget = (TextView) v;
                    //view being dragged and dropped
                    TextView dropped = (TextView) view;
                    //update the text in the target view to reflect the data being dropped
                    dropTarget.setText(dropped.getText());
                    //make it bold to highlight the fact that an item has been dropped
                    dropTarget.setTypeface(Typeface.DEFAULT_BOLD);
                    //if an item has already been dropped here, there will be a tag
                    Object tag = dropTarget.getTag();
                    //if there is already an item here, set it back visible in its original place
                    if(tag!=null)
                    {
                        //the tag is the view id already dropped here
                        int existingID = (Integer)tag;
                        //set the original view visible again
                        findViewById(existingID).setVisibility(View.VISIBLE);
                    }
                    //set the tag in the target view to the ID of the view being dropped
                    dropTarget.setTag(dropped.getId());
                    dropTarget.setBackgroundResource(R.drawable.rounded_corner);


                    if (dropTarget.getId()==(int)dropTarget.getTag()+1000){
                        tabPoprawnosci.set(dropTarget.getId()-2000,1);
                    } else {
                        tabPoprawnosci.set(dropTarget.getId() - 2000, 0);
                    }

                    if (czyWszystkoSchowane((LinearLayout)findViewById(R.id.layZrodlo))) {
                        if (tabPoprawnosci.contains(0)) { przegrana();   }
                        else { wygrana();   }
                    }

                    break;
                case DragEvent.ACTION_DRAG_ENDED:
                    //no action necessary
                    break;
                default:
                    break;
            }
            return true;
        }
    }

    private boolean czyWszystkoSchowane(LinearLayout aLay){
        boolean czySchowane=true;

        for(int i=0;i<aLay.getChildCount();i++){
            View child=aLay.getChildAt(i);
            int vv=child.getVisibility();
            if (vv==View.VISIBLE) {
                czySchowane=false;
                break;
            }
        }
        return czySchowane;
    }

    private void wygrana() {
        Random rand = new Random();
        int x = rand.nextInt(tada.size());
        sounds.play((int)tada.get(x),1f,1f,0,0,1.5f); //dzwiek sukcesu

        TextView tv=(TextView) findViewById(R.id.komunikat);
        tv.setText("BRAWO");
        komunikat.setVisibility(View.VISIBLE);
        usmiech.setVisibility(View.VISIBLE);
        podpowiedz.setVisibility(View.INVISIBLE);
        btnPodp.setEnabled(false);

        ImageView kwiatek=new ImageView(this);
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        if (layPkt.getChildCount()>14){
            params.setMargins(0, 0, 0, 300);
            params.gravity=Gravity.TOP;
            kwiatek.setImageResource(R.drawable.flower2);
            kwiatek.setLayoutParams(params);
            layPkt2.addView(kwiatek);
        } else{
            kwiatek.setImageResource(R.drawable.flower);
            layPkt.addView(kwiatek);
        }
    }

    private void przegrana(){
        Random rand = new Random();
        int x = rand.nextInt(err.size());
        sounds.play((int)err.get(x),1f,1f,0,0,1.5f); //dzwiek przegranej

        TextView tv=(TextView) findViewById(R.id.komunikat);
        tv.setText("SPRÓBUJ PONOWNIE");
        komunikat.setVisibility(View.VISIBLE);
        smutek.setVisibility(View.VISIBLE);
        podpowiedz.setVisibility(View.INVISIBLE);
        wyswietlOpowiedz();
        btnPodp.setEnabled(false);

        layPkt.removeAllViewsInLayout();
        layPkt2.removeAllViewsInLayout();
        //todo usunac kwiatki
    }

    private void wyswietlOpowiedz(){
        odpowiedz.setText(odpTXT.toUpperCase());
        odpowiedz.setVisibility(View.VISIBLE);

    }

    private void wyswietlPodpowiedz(){
        podpowiedz.setText(kategoria.toUpperCase());
        podpowiedz.setVisibility(View.VISIBLE);
    }

    private void rozbicieSlowa(){
        TextView sylaba1= (TextView)findViewById(R.id.s1);
        TextView sylaba2= (TextView)findViewById(R.id.s2);
        TextView sylaba3= (TextView)findViewById(R.id.s3);
        TextView sylaba4= (TextView)findViewById(R.id.s4);
        TextView sylaba5= (TextView)findViewById(R.id.s5);

        AnimationSet animationSet1 = new AnimationSet(true);
        AnimationSet animationSet2 = new AnimationSet(true);
        AnimationSet animationSet3 = new AnimationSet(true);
        AnimationSet animationSet4 = new AnimationSet(true);
        AnimationSet animationSet5 = new AnimationSet(true);

        AlphaAnimation fadeIn = new AlphaAnimation(0.0f, 1.0f);
        fadeIn.setDuration(1000);
        fadeIn.setFillAfter(true);

        TranslateAnimation animS1 = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF,0, Animation.ABSOLUTE,-500,
                Animation.RELATIVE_TO_SELF,0, Animation.RELATIVE_TO_SELF,0);
        animS1.setStartOffset(1000);
        animS1.setDuration(1000);
        animS1.setFillAfter(true); //HERE

        TranslateAnimation animS2 = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF,0, Animation.ABSOLUTE,-250,
                Animation.RELATIVE_TO_SELF,0, Animation.RELATIVE_TO_SELF,0);
        animS2.setStartOffset(1000);
        animS2.setDuration(1000);
        animS2.setFillAfter(true); //HERE

        TranslateAnimation animS3 = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF,0, Animation.ABSOLUTE,0,
                Animation.RELATIVE_TO_SELF,0, Animation.RELATIVE_TO_SELF,0);
        animS3.setStartOffset(1000);
        animS3.setDuration(1000);
        animS3.setFillAfter(true); //HERE

        TranslateAnimation animS4 = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF,0, Animation.ABSOLUTE,250,
                Animation.RELATIVE_TO_SELF,0, Animation.RELATIVE_TO_SELF,0);
        animS4.setStartOffset(1000);
        animS4.setDuration(1000);
        animS4.setFillAfter(true); //HERE

        TranslateAnimation animS5 = new TranslateAnimation(
                Animation.RELATIVE_TO_SELF,0, Animation.ABSOLUTE,500,
                Animation.RELATIVE_TO_SELF,0, Animation.RELATIVE_TO_SELF,0);
        animS5.setStartOffset(1000);
        animS5.setDuration(1000);
        animS5.setFillAfter(true); //HERE

        AlphaAnimation fadeOut = new AlphaAnimation(1.0f, 0.0f);
        fadeOut.setStartOffset(2000);
        fadeOut.setDuration(1000);
        fadeOut.setFillAfter(true);

        animationSet1.addAnimation(fadeIn);
        animationSet1.addAnimation(animS1);
        animationSet1.addAnimation(fadeOut);

        animationSet2.addAnimation(fadeIn);
        animationSet2.addAnimation(animS2);
        animationSet2.addAnimation(fadeOut);

        animationSet3.addAnimation(fadeIn);
        animationSet3.addAnimation(animS3);
        animationSet3.addAnimation(fadeOut);

        animationSet4.addAnimation(fadeIn);
        animationSet4.addAnimation(animS4);
        animationSet4.addAnimation(fadeOut);

        animationSet5.addAnimation(fadeIn);
        animationSet5.addAnimation(animS5);
        animationSet5.addAnimation(fadeOut);

        sylaba1.startAnimation(animationSet1);
        sylaba2.startAnimation(animationSet2);
        sylaba3.startAnimation(animationSet3);
        sylaba4.startAnimation(animationSet4);
        sylaba5.startAnimation(animationSet5);
        sylaba1.setVisibility(View.INVISIBLE);
        sylaba2.setVisibility(View.INVISIBLE);
        sylaba3.setVisibility(View.INVISIBLE);
        sylaba4.setVisibility(View.INVISIBLE);
        sylaba5.setVisibility(View.INVISIBLE);
    }


    private static int[] RandomizeArray(int[] array) {
        do {
            Random rgen = new Random();  // Random number generator
            for (int i = 0; i < array.length; i++) {
                int randomPosition = rgen.nextInt(array.length);
                int temp = array[i];
                array[i] = array[randomPosition];
                array[randomPosition] = temp;
            }
        } while (array[0] == 0 && array[1] == 1 && array[2] == 2);
        return array;
    }

    @Override
    public void onResume(){
        super.onResume();
        animacjaChmur();
    }
}